//scoring
function Scoring(){
    //registrate particle hit
    var particleHit =0;
    //check particle hit
    if (particleHit >0){
    //increase score    
    totalscore += totalscore;
    //update score
    eScore ="Score: "+totalscore;
    document.getElementById('score').innerHTML = eScore;
    }
}