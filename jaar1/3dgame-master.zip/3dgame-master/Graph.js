//graph
function Graph(){
//create graph


//graph coords

}